package JAVA_YASH;
import java.util.*;


public class Useme{
    public int area(int l,int b){
        return l*b;
    }
    public double percentage(double m,double t){
        return (m*100)/t;
    }
}
package JAVA_YASH;

import java.io.File;

public class DeleteFile {
    public static void main(String[] args) {
        File file = new File("JAVA_YASH/source.txt"); // replace with your file name

        if (file.delete()) {
            System.out.println("File deleted successfully");
        } else {
            System.out.println("Failed to delete the file");
        }
    }
}

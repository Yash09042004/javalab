
package JAVA_ass_4;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RegistrationForm extends JFrame {
    JTextField nameField, ageField, courseField;
    JButton submitButton;

    public RegistrationForm() {
        createUI();
    }

    private void createUI() {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(400, 200);
        setLayout(new GridLayout(4, 2));

        JLabel nameLabel = new JLabel("Name:");
        nameField = new JTextField();

        JLabel ageLabel = new JLabel("Age:");
        ageField = new JTextField();

        JLabel courseLabel = new JLabel("Course:");
        courseField = new JTextField();

        submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String age = ageField.getText();
                String course = courseField.getText();

                System.out.println("Student Information:");
                System.out.println("Name: " + name);
                System.out.println("Age: " + age);
                System.out.println("Course: " + course);
            }
        });

        add(nameLabel);
        add(nameField);
        add(ageLabel);
        add(ageField);
        add(courseLabel);
        add(courseField);
        add(submitButton);

        setVisible(true);
    }

    public static void main(String[] args) {
        new RegistrationForm();
    }
}

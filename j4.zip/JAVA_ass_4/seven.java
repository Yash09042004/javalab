package JAVA_ass_4;
import java.util.*;

abstract class Abstract{
    abstract void rectangle (int length , int breadth);
    abstract void square(int side);
    abstract void circle(int radius);
}

class Area extends Abstract{
    @Override
    void rectangle(int length,int breadth){
        int area = length*breadth;
        System.out.println("area of rect : "+area);
    }
    @Override
    void square(int side){
        int area = side*side;
        System.out.println("area of square : "+area);

    }
    @Override
    void circle(int radius){
        int area = radius*radius;
        System.out.println("area of circle : "+area);
    }


}
public class seven {
    public static void main(String[] args) {
      Area a = new Area();
      a.rectangle(1,1);
      a.square(10);
      a.circle(20);
      
    }
}

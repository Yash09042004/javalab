package Assignment_5;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SimpleCalculator2 {
    private JFrame frame;
    private JTextField textField;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SimpleCalculator2 window = new SimpleCalculator2();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public SimpleCalculator2() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 200, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        textField = new JTextField();
        textField.setBounds(15, 10, 150, 30);
        frame.getContentPane().add(textField);
        textField.setColumns(10);

        // creating buttons and adding action listeners
        JButton btn1 = new JButton("1");
        btn1.addActionListener(e -> textField.setText(textField.getText() + "1"));
        btn1.setBounds(15, 60, 50, 50);
        frame.getContentPane().add(btn1);

        // repeat above steps for buttons 2-9, 0, +, -, *, /

        JButton btnEqual = new JButton("=");
        btnEqual.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // perform the operation and set the result to textField
                // for now, just display the text in the textField
                System.out.println(textField.getText());
            }
        });
        btnEqual.setBounds(75, 220, 50, 50);
        frame.getContentPane().add(btnEqual);
    }
}


public class Main{
    int prn;
    String name;
     Main(){
        this.prn = 0;
        this.name = "god";
    }

    Main(int prn, String name){
        this.prn = prn;
        this.name = name;
    }
    void display(){
        System.out.println("prn: "+prn+" name: "+name);
    }

    void change(){
        this.name = name+" is unbeatable if he decided";
        this.prn = prn+1;
    }
    int calc(int s){
        int h = s/3600;
        int m = (s%3600)/60;
        int sec = s%60;
        System.out.println("Hours: "+h+" Minutes: "+m+" Seconds: "+sec);
        return h;
    }


    public static void main(String[] args){
      Main student = new Main(27,"yash");
      student.change();
        student.display();
        int hours = student.calc(7260);
        System.out.println("Hours: "+hours);

    }
}
package JAVA_YASH;

import java.io.FileOutputStream;
import java.io.IOException;

public class WriteBytes {
    public static void main(String[] args) {
        String data = "Hello, World!";
        byte[] bytes = data.getBytes();

        try {
            FileOutputStream fos = new FileOutputStream("output.txt");
            fos.write(bytes);
            fos.close();
            System.out.println("Bytes written to the file successfully!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

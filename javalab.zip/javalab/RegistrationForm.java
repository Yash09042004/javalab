import javax.swing.*;
import java.awt.*;

public class RegistrationForm extends JFrame {
    private JTextField nameField, ageField;
    private JComboBox<String> genderField, courseField;

    public RegistrationForm() {
        this.setTitle("Student Registration Form");
        this.setSize(500, 800);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new GridLayout(5, 2));

        this.add(new JLabel("Name: "));
        nameField = new JTextField();
        this.add(nameField);

        this.add(new JLabel("Age: "));
        ageField = new JTextField();
        this.add(ageField);

        this.add(new JLabel("Gender: "));
        genderField = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        this.add(genderField);

        this.add(new JLabel("Course: "));
        courseField = new JComboBox<>(new String[]{"Course 1", "Course 2", "Course 3"});
        this.add(courseField);

        JButton submitButton = new JButton("Submit");
        this.add(submitButton);

        this.setVisible(true);
    }

    public static void main(String[] args) {
        new RegistrationForm();
    }
}
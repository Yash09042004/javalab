package JAVA_YASH;
import java.io.*;

public class copy1to2 {
    public static void main(String[] args) {
        File sourceFile = new File("/home/yash/Desktop/Yash_The_Coder/CPLOVE/JAVA_YASH/source.txt");
        File destinationFile = new File("/home/yash/Desktop/Yash_The_Coder/CPLOVE/JAVA_YASH/destination.txt");

        try (BufferedReader reader = new BufferedReader(new FileReader(sourceFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(destinationFile))) {

            String line;
            while ((line = reader.readLine()) != null) {
                String[] words = line.split(" ");
                for(String word : words){
                    int number = Integer.parseInt(word);
                    if (number % 5 == 0) {
                        writer.write(word);
                        writer.newLine();
                    }
                }
                
            }

            System.out.println("File copied successfully!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

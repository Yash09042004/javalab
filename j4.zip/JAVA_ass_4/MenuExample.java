package JAVA_ass_4;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MenuExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Menu Example");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JLabel label = new JLabel("Current State", SwingConstants.CENTER);
        frame.add(label, BorderLayout.CENTER);

        // Menu-A with menu items Up and Down
        JMenuBar menuBarA = new JMenuBar();
        JMenu menuA = new JMenu("Menu-A");
        JMenuItem upItem = new JMenuItem("Up");
        upItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                label.setText("Up was clicked");
            }
        });
        JMenuItem downItem = new JMenuItem("Down");
        downItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                label.setText("Down was clicked");
            }
        });
        menuA.add(upItem);
        menuA.add(downItem);
        menuBarA.add(menuA);

        // Menu-B with menu item Reset
        JMenuBar menuBarB = new JMenuBar();
        JMenu menuB = new JMenu("Menu-B");
        JMenuItem resetItem = new JMenuItem("Reset");
        resetItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                label.setText("Reset was clicked");
            }
        });
        menuB.add(resetItem);
        menuBarB.add(menuB);

        // Add menu bars to frame
        frame.setJMenuBar(menuBarA);
        frame.add(menuBarB, BorderLayout.SOUTH);

        frame.setVisible(true);
    }
}

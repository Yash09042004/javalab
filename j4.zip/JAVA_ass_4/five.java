package JAVA_ass_4;
import java.util.*;
public class five {
    public static void main(String[] args) {
            
        final int speed  =100;
        int currspeed;
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the number : ");
        currspeed = sc.nextInt();
        if(currspeed<=speed){
            System.out.println("in Limit ");
        }else{
            System.out.println("Be slowed down plz ");
        }
    }
    
}

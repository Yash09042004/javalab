package JAVA_YASH;

import java.io.FileInputStream;
import java.io.IOException;

public class ReadFromFile {
    public static void main(String[] args) {
        FileInputStream fis = null;
        try {
            fis = new FileInputStream("JAVA_YASH/source.txt"); // replace with your file name

            int index = 4; // replace with the index you want to start reading from
            fis.skip(index);

            int content;
            while ((content = fis.read()) != -1) {
                // convert to char and display it
                System.out.print((char) content);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (fis != null)
                    fis.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}

package JAVA_ass_6;

import javax.swing.*;
import java.awt.*;

public class AdmissionForm {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Admission Form");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(5, 2));

        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField();
        JLabel ageLabel = new JLabel("Age:");
        JTextField ageField = new JTextField();
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField();
        JLabel courseLabel = new JLabel("Course:");
        JTextField courseField = new JTextField();

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(e -> {
            // Handle submit button action here
            String name = nameField.getText();
            String age = ageField.getText();
            String email = emailField.getText();
            String course = courseField.getText();

            System.out.println("Name: " + name);
            System.out.println("Age: " + age);
            System.out.println("Email: " + email);
            System.out.println("Course: " + course);
        });

        frame.add(nameLabel);
        frame.add(nameField);
        frame.add(ageLabel);
        frame.add(ageField);
        frame.add(emailLabel);
        frame.add(emailField);
        frame.add(courseLabel);
        frame.add(courseField);
        frame.add(submitButton);

        frame.setVisible(true);
    }
}

package JAVA_YASH;

import java.io.File;
import java.text.SimpleDateFormat;


public class FileInfo {
    
    public class student{
        int name = 1 ;
        int roll = 2;
    
    
    
    }

    public static void main(String[] args) {
        FileInfo f = new FileInfo();
        student s = f.new student();
        File file = new File("JAVA_YASH/destination.txt"); // replace with your file name

        if (file.exists()) {
            System.out.println("File name: " + file.getName());
            System.out.println("Absolute path: " + file.getAbsolutePath());
            System.out.println("Writeable: " + file.canWrite());
            System.out.println("Readable: " + file.canRead());
            System.out.println("File size in bytes: " + file.length());

            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
            System.out.println("Last modified: " + sdf.format(file.lastModified()));
        } else {
            System.out.println("The file does not exist.");
        }
    }
}

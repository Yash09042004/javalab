package JAVA_YASH;
import java.util.*;


class Book {
    int isbnNumber;
    String name;
    double price;

    Book(int isbnNumber, String name, double price) {
        this.isbnNumber = isbnNumber;
        this.name = name;
        this.price = price;
    }

    public String toString() {
        return "ISBN Number: " + isbnNumber + ", Name: " + name + ", Price: " + price;
    }
}

public class Main {
    public static void main(String[] args) {
        Book book1 = new Book(1, "Book One", 9.99);
        Book book2 = new Book(2, "Book Two", 19.99);
        Book book3 = new Book(3, "Book Three", 29.99);

        // ArrayList
        List<Book> arr = new ArrayList<>();
        arr.add(book1);
        arr.add(book2);
        arr.add(book3);
        System.out.println("ArrayList: " + arr);

        // LinkedList
        List<Book> linkedList = new LinkedList<>();
        linkedList.add(book1);
        linkedList.add(book2);
        linkedList.add(book3);
        System.out.println("LinkedList: " + linkedList);

        // ArrayDeque
        Deque<Book> arrayDeque = new ArrayDeque<>();
        arrayDeque.add(book1);
        arrayDeque.add(book2);
        arrayDeque.add(book3);
        System.out.println("ArrayDeque: " + arrayDeque);

        // HashSet
        Set<Book> hashSet = new HashSet<>();
        hashSet.add(book1);
        hashSet.add(book2);
        hashSet.add(book3);
        System.out.println("HashSet: " + hashSet);

        // TreeSet - Note: Book class needs to implement Comparable<Book> or you need to pass Comparator<Book> to TreeSet
        // Set<Book> treeSet = new TreeSet<>();
        // treeSet.add(book1);
        // treeSet.add(book2);
        // treeSet.add(book3);
        // System.out.println("TreeSet: " + treeSet);

        // HashMap
        Map<Integer, Book> hashMap = new HashMap<>();
        hashMap.put(book1.isbnNumber, book1);
        hashMap.put(book2.isbnNumber, book2);
        hashMap.put(book3.isbnNumber, book3);
        System.out.println("HashMap: " + hashMap);

        // LinkedHashMap
       Map<Integer,Book>mp = new LinkedHashMap<>();
       mp.put(book1.isbnNumber,book1);
         mp.put(book2.isbnNumber,book2);
            mp.put(book3.isbnNumber,book3);
        System.out.println("LinkedHashMap: " + mp);
    }
}

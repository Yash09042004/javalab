package Assignment_5;

import javax.swing.*;
import java.awt.event.*;
import java.awt.EventQueue;

public class SimpleCalculator {
    private JFrame frame;
    private JTextField textField;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SimpleCalculator window = new SimpleCalculator();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public SimpleCalculator() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 200, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        textField = new JTextField();
        textField.setBounds(15, 10, 150, 30);
        frame.getContentPane().add(textField);
        textField.setColumns(10);

        // creating buttons and adding action listeners
        JButton btn1 = new JButton("1");
        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                textField.setText(textField.getText() + "1");
            }
        });
        btn1.setBounds(15, 60, 50, 50);
        frame.getContentPane().add(btn1);

        // repeat above steps for buttons 2-9, 0, +, -, *, /

        JButton btnEqual = new JButton("=");
        btnEqual.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textField.getText();
                // perform the operation and set the result to textField
            }
        });
        btnEqual.setBounds(75, 220, 50, 50);
        frame.getContentPane().add(btnEqual);
    }
}
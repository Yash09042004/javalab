import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FactorialCalculator extends JFrame {
    private JTextField inputField;
    private JTextArea resultArea;
    private JButton calculateButton;

    public FactorialCalculator() {
        this.setTitle("Factorial Calculator");
        this.setSize(300, 200);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new FlowLayout());

        inputField = new JTextField(10);
        this.add(new JLabel("Enter a number: "));
        this.add(inputField);

        calculateButton = new JButton("Calculate Factorial");
        calculateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int num = Integer.parseInt(inputField.getText());
                    if (num < 0) {
                        resultArea.setText("Error: Factorial is not defined for negative numbers.");
                    } else {
                        long factorial = calculateFactorial(num);
                        resultArea.setText("Factorial of " + num + " is " + factorial);
                    }
                } catch (NumberFormatException ex) {
                    resultArea.setText("Error: Please enter a valid integer.");
                }
            }
        });
        this.add(calculateButton);

        resultArea = new JTextArea(3, 20);
        resultArea.setEditable(false);
        this.add(new JScrollPane(resultArea));

        this.setVisible(true);
    }

    private long calculateFactorial(int num) {
        long result = 1;
        for (int i = 1; i <= num; i++) {
            result *= i;
        }
        return result;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new FactorialCalculator();
            }
        });
    }
}
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginForm extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginForm() {
        this.setTitle("Website Login Form");
        this.setSize(300, 200);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new GridLayout(3, 2));

        this.add(new JLabel("Username: "));
        usernameField = new JTextField();
        this.add(usernameField);

        this.add(new JLabel("Password: "));
        passwordField = new JPasswordField();
        this.add(passwordField);

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Handle login
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                // Add code here to authenticate the user
                System.out.println("Username: " + username + ", Password: " + password);
            }
        });
        this.add(loginButton);

        this.setVisible(true);
    }

    public static void main(String[] args) {
        new LoginForm();
    }
}